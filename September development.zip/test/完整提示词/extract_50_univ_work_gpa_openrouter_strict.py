#!/usr/bin/env python3
# -*- coding: utf-8 -*-


import os, sys, re, json, argparse, asyncio
import pandas as pd
from typing import List, Optional
from pydantic import BaseModel, Field, field_validator

try:
    from pydantic_ai import Agent
except Exception as e:
    print("ERROR: pydantic-ai not installed. Run: pip install pydantic-ai", file=sys.stderr)
    raise

# ========== Schema ==========

class EducationItem(BaseModel):
    university: Optional[str] = None
    degree: Optional[str] = None
    major: Optional[str] = None
    gpa_value: Optional[float] = None
    gpa_scale: Optional[float] = None
    raw_gpa_text: Optional[str] = None
    @field_validator("gpa_value")
    @classmethod
    def clip_val(cls, v):
        if v is None: return v
        try: v = float(v)
        except: return None
        if v < 0 or v > 1000: return None
        return v

class JobItem(BaseModel):
    organization: Optional[str] = None
    role: Optional[str] = None
    employment_type: Optional[str] = None
    start_date_text: Optional[str] = None
    end_date_text: Optional[str] = None
    raw_span: Optional[str] = None

class ExtractionResult(BaseModel):
    education: List[EducationItem] = Field(default_factory=list)
    jobs: List[JobItem] = Field(default_factory=list)

# ========== Prompt with rules ==========

INSTRUCTIONS = """
You are an information extraction engine. Return ONLY structured JSON matching the schema.

Entities:
- EDUCATION: university, degree, major, GPA (value/scale/raw text).
- JOBS: organization, role, employment_type, start/end dates, raw snippet.

GPA rules:
- 92/100 → gpa_value=92.0, gpa_scale=100
- 3.85/4.0 → gpa_value=3.85, gpa_scale=4
- GPA 3.9 → gpa_value=3.9, gpa_scale=null
- Extract GPA only if clearly marked as GPA. Ignore isolated numbers (e.g., "4") unless explicitly labeled GPA.
- Always keep the original mention in raw_gpa_text.
- NEVER convert scales.

Education rules:
- If degree or major is not explicitly mentioned, set them to null (NOT "unknown").
- Accept common abbreviations (B.S., M.S., PhD) or words (Bachelor, Master, Doctor).
- If only university name is listed without degree/major, leave degree and major null.
- Do not duplicate the same university multiple times unless different degrees are explicitly listed.

Job/Internship rules:
- organization: extract company/organization/university if explicitly tied to a role.
- role: extract the clearest title (e.g., "Research Assistant", "Software Engineer"). If unclear, leave null.
- employment_type must be one of: internship, full-time, part-time, contract, research, teaching, volunteer. Use null if not determinable.
- Classify correctly: “intern”, “internship”, “summer analyst” → internship; “Research Assistant” → research; “Teaching Assistant” → teaching.
- If organization is a university but context is a job role, keep as organization and ensure role is filled.

Date rules:
- If no explicit date is found, leave start_date_text and end_date_text null (NOT "unknown").
- If present, capture free-text spans like "Jun 2021 – Aug 2021" or "present".

STRICT constraints:
- IGNORE exam/test scores: SAT, ACT, GRE, GMAT, TOEFL, IELTS
- IGNORE scholarship %, ranks, percentile (Top x%), awards/honors — NOT GPA
- Do NOT invent universities, organizations, roles, dates, or GPA
- Return JSON only, no commentary
""".strip()

# ========== Helpers ==========

def concat_row_text(row: pd.Series) -> str:
    return " | ".join([str(v).strip() for v in row.values if pd.notna(v) and str(v).strip()])

async def _maybe_await(x):
    if asyncio.iscoroutine(x): return await x
    return x

async def _call_agent(agent, text):
    res = await _maybe_await(agent.run(text))
    return res.output if hasattr(res, "output") else res

# ========== Badcase detection ==========

def flag_badcases(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    def suspicious(v, s):
        try: v, s = float(v), float(s) if s else None
        except: return True
        if v is None: return False
        if s == 4 and v > 4: return True
        if s == 100 and v <= 4.5: return True
        if v > 100 and (s is None or s <= 100): return True
        return False
    df["flag_suspicious_gpa"] = df.apply(lambda r: suspicious(r.get("gpa_value"), r.get("gpa_scale")), axis=1)
    df["flag_exam_token"] = df.apply(lambda r: bool(re.search(r"(SAT|ACT|GRE|GMAT|TOEFL|IELTS)", str(r.get("raw_gpa_text") or "")+str(r.get("raw_span") or ""), re.I)), axis=1)
    # group summary
    summary = df.groupby("row_index").agg(
        any_univ=("university", lambda x: x.notna().any()),
        any_gpa=("gpa_value", lambda x: x.notna().any()),
        suspicious=("flag_suspicious_gpa","any"),
        exam=("flag_exam_token","any")
    ).reset_index()
    bad = summary[(summary["any_gpa"] & ~summary["any_univ"]) | summary["suspicious"] | summary["exam"]]
    return df.merge(bad[["row_index"]], on="row_index", how="inner")

# ========== Main ==========

async def _amain(args):
    if "OPENROUTER_API_KEY" not in os.environ:
        print("ERROR: setx OPENROUTER_API_KEY \"sk-or-v1...\"", file=sys.stderr); sys.exit(1)
    df = pd.read_csv(args.csv).iloc[args.start: args.start+args.limit].copy()
    df["_text"] = df.apply(concat_row_text, axis=1)
    agent = Agent(args.model or os.getenv("OPENROUTER_MODEL","openrouter:openai/gpt-4o-mini"),
                  instructions=INSTRUCTIONS, output_type=ExtractionResult)
    out_jsonl, out_csv, out_bad = f"{args.out}.jsonl", f"{args.out}.csv", f"{args.out}_badcases.csv"
    open(out_jsonl,"w",encoding="utf-8").close()
    sem = asyncio.Semaphore(max(1,args.concurrency))
    async def run_one(i,t):
        async with sem:
            try: out = await _call_agent(agent,t)
            except Exception as e: print(f"[WARN] row{i} {e}"); out=ExtractionResult()
            return i,out
    results = await asyncio.gather(*[asyncio.create_task(run_one(i,t)) for i,t in enumerate(df["_text"],start=args.start)])
    rows=[]
    with open(out_jsonl,"a",encoding="utf-8") as f:
        for idx,out in results:
            f.write(json.dumps(out.model_dump(),ensure_ascii=False)+"\n")
            for ed in out.education:
                rows.append({"row_index":idx,"entity_type":"education",**ed.model_dump()})
            for jb in out.jobs:
                rows.append({"row_index":idx,"entity_type":"job",**jb.model_dump()})
            if not (out.education or out.jobs): rows.append({"row_index":idx,"entity_type":"none"})
    pd.DataFrame(rows).to_csv(out_csv,index=False,encoding="utf-8-sig")
    flag_badcases(pd.DataFrame(rows)).to_csv(out_bad,index=False,encoding="utf-8-sig")
    print(f"Done. JSONL:{out_jsonl}, CSV:{out_csv}, BAD:{out_bad}")

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--csv",required=True); ap.add_argument("--out",required=True)
    ap.add_argument("--start",type=int,default=0); ap.add_argument("--limit",type=int,default=50)
    ap.add_argument("--concurrency",type=int,default=1); ap.add_argument("--model",type=str,default=None)
    args=ap.parse_args(); asyncio.run(_amain(args))

if __name__=="__main__": main()
