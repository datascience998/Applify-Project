#!/usr/bin/env python3
# -*- coding: utf-8 -*-


import os, sys, re, json, argparse, asyncio
import pandas as pd
from typing import List, Optional
from pydantic import BaseModel, Field, field_validator

try:
    from pydantic_ai import Agent
except Exception as e:
    print("ERROR: pydantic-ai not installed. Run: pip install pydantic-ai", file=sys.stderr)
    raise

# ========== Schema ==========

class EducationItem(BaseModel):
    university: Optional[str] = None
    degree: Optional[str] = None
    major: Optional[str] = None
    gpa_value: Optional[float] = None
    gpa_scale: Optional[float] = None
    raw_gpa_text: Optional[str] = None
    @field_validator("gpa_value")
    @classmethod
    def clip_val(cls, v):
        if v is None: return v
        try: v = float(v)
        except: return None
        if v < 0 or v > 1000: return None
        return v

class JobItem(BaseModel):
    organization: Optional[str] = None
    role: Optional[str] = None
    employment_type: Optional[str] = None
    start_date_text: Optional[str] = None
    end_date_text: Optional[str] = None
    raw_span: Optional[str] = None

class ExtractionResult(BaseModel):
    education: List[EducationItem] = Field(default_factory=list)
    jobs: List[JobItem] = Field(default_factory=list)

# ========== Prompt with rules ==========

INSTRUCTIONS = """
Extract universities, degrees, majors, GPAs, and jobs/internships.
Follow schema strictly.

STRICT rules:
- GPA: handle 92/100, 3.8/4.0, GPA 3.9
- IGNORE SAT/ACT/GRE/GMAT/TOEFL/IELTS, scholarship %, rank, Top x%
- Only link GPA to a university if nearby (same sentence/150 chars)
- Employment_type in {internship, full-time, part-time, contract, research, teaching, volunteer, unknown}
- Do NOT invent missing data
Return JSON only.
""".strip()

# ========== Helpers ==========

def concat_row_text(row: pd.Series) -> str:
    return " | ".join([str(v).strip() for v in row.values if pd.notna(v) and str(v).strip()])

async def _maybe_await(x):
    if asyncio.iscoroutine(x): return await x
    return x

async def _call_agent(agent, text):
    res = await _maybe_await(agent.run(text))
    return res.output if hasattr(res, "output") else res

# ========== Badcase detection ==========

def flag_badcases(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    def suspicious(v, s):
        try: v, s = float(v), float(s) if s else None
        except: return True
        if v is None: return False
        if s == 4 and v > 4: return True
        if s == 100 and v <= 4.5: return True
        if v > 100 and (s is None or s <= 100): return True
        return False
    df["flag_suspicious_gpa"] = df.apply(lambda r: suspicious(r.get("gpa_value"), r.get("gpa_scale")), axis=1)
    df["flag_exam_token"] = df.apply(lambda r: bool(re.search(r"(SAT|ACT|GRE|GMAT|TOEFL|IELTS)", str(r.get("raw_gpa_text") or "")+str(r.get("raw_span") or ""), re.I)), axis=1)
    # group summary
    summary = df.groupby("row_index").agg(
        any_univ=("university", lambda x: x.notna().any()),
        any_gpa=("gpa_value", lambda x: x.notna().any()),
        suspicious=("flag_suspicious_gpa","any"),
        exam=("flag_exam_token","any")
    ).reset_index()
    bad = summary[(summary["any_gpa"] & ~summary["any_univ"]) | summary["suspicious"] | summary["exam"]]
    return df.merge(bad[["row_index"]], on="row_index", how="inner")

# ========== Main ==========

async def _amain(args):
    if "OPENROUTER_API_KEY" not in os.environ:
        print("ERROR: setx OPENROUTER_API_KEY \"sk-or-v1...\"", file=sys.stderr); sys.exit(1)
    df = pd.read_csv(args.csv).iloc[args.start: args.start+args.limit].copy()
    df["_text"] = df.apply(concat_row_text, axis=1)
    agent = Agent(args.model or os.getenv("OPENROUTER_MODEL","openrouter:openai/gpt-4o-mini"),
                  instructions=INSTRUCTIONS, output_type=ExtractionResult)
    out_jsonl, out_csv, out_bad = f"{args.out}.jsonl", f"{args.out}.csv", f"{args.out}_badcases.csv"
    open(out_jsonl,"w",encoding="utf-8").close()
    sem = asyncio.Semaphore(max(1,args.concurrency))
    async def run_one(i,t):
        async with sem:
            try: out = await _call_agent(agent,t)
            except Exception as e: print(f"[WARN] row{i} {e}"); out=ExtractionResult()
            return i,out
    results = await asyncio.gather(*[asyncio.create_task(run_one(i,t)) for i,t in enumerate(df["_text"],start=args.start)])
    rows=[]
    with open(out_jsonl,"a",encoding="utf-8") as f:
        for idx,out in results:
            f.write(json.dumps(out.model_dump(),ensure_ascii=False)+"\n")
            for ed in out.education:
                rows.append({"row_index":idx,"entity_type":"education",**ed.model_dump()})
            for jb in out.jobs:
                rows.append({"row_index":idx,"entity_type":"job",**jb.model_dump()})
            if not (out.education or out.jobs): rows.append({"row_index":idx,"entity_type":"none"})
    pd.DataFrame(rows).to_csv(out_csv,index=False,encoding="utf-8-sig")
    flag_badcases(pd.DataFrame(rows)).to_csv(out_bad,index=False,encoding="utf-8-sig")
    print(f"Done. JSONL:{out_jsonl}, CSV:{out_csv}, BAD:{out_bad}")

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--csv",required=True); ap.add_argument("--out",required=True)
    ap.add_argument("--start",type=int,default=0); ap.add_argument("--limit",type=int,default=50)
    ap.add_argument("--concurrency",type=int,default=1); ap.add_argument("--model",type=str,default=None)
    args=ap.parse_args(); asyncio.run(_amain(args))

if __name__=="__main__": main()
