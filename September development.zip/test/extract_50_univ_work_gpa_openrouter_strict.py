#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os, sys, re, json, argparse, asyncio
from typing import List, Optional, Tuple
import pandas as pd
from pydantic import BaseModel, Field, field_validator

# ======== Pydantic-AI Agent ========
try:
    from pydantic_ai import Agent
except Exception as e:
    print("ERROR: pydantic-ai not installed. Run: pip install pydantic-ai", file=sys.stderr)
    raise

# ======== Schema ========

class EducationItem(BaseModel):
    university: Optional[str] = None
    degree: Optional[str] = None
    major: Optional[str] = None
    gpa_value: Optional[float] = None
    gpa_scale: Optional[float] = None
    raw_gpa_text: Optional[str] = None
    @field_validator("gpa_value")
    @classmethod
    def _clip_val(cls, v):
        if v is None: return v
        try: v = float(v)
        except: return None
        if v < 0 or v > 1000: return None
        return v

class JobItem(BaseModel):
    organization: Optional[str] = None
    role: Optional[str] = None
    employment_type: Optional[str] = None
    start_date_text: Optional[str] = None
    end_date_text: Optional[str] = None
    raw_span: Optional[str] = None

class ExtractionResult(BaseModel):
    education: List[EducationItem] = Field(default_factory=list)
    jobs: List[JobItem] = Field(default_factory=list)

# ======== INSTRUCTIONS ========

INSTRUCTIONS = """
You are an information extraction engine. Return ONLY structured JSON matching the schema.

Entities:
- EDUCATION: university, degree, major, GPA (value/scale/raw text).
- JOBS: organization, role, employment_type, start/end dates, raw snippet.

GPA rules:
- 92/100 → gpa_value=92.0, gpa_scale=100
- 3.85/4.0 → gpa_value=3.85, gpa_scale=4
- GPA 3.9 → gpa_value=3.9, gpa_scale=null
- Extract GPA only if clearly marked as GPA. Ignore isolated numbers (e.g., "4") unless explicitly labeled GPA.
- Always keep the original mention in raw_gpa_text.
- NEVER convert scales.

Education rules:
- If degree or major is not explicitly mentioned, set them to null (NOT "unknown").
- Accept common abbreviations (B.S., M.S., PhD) or words (Bachelor, Master, Doctor).
- If only university name is listed without degree/major, leave degree and major null.
- Do not duplicate the same university multiple times unless different degrees are explicitly listed.

Job/Internship rules:
- organization: extract company/organization/university if explicitly tied to a role.
- role: extract the clearest title (e.g., "Research Assistant", "Software Engineer"). If unclear, leave null.
- employment_type must be one of: internship, full-time, part-time, contract, research, teaching, volunteer. Use null if not determinable.
- Classify correctly: “intern”, “internship”, “summer analyst” → internship; “Research Assistant” → research; “Teaching Assistant” → teaching.
- If organization is a university but context is a job role, keep as organization and ensure role is filled.

Date rules:
- If no explicit date is found, leave start_date_text and end_date_text null (NOT "unknown").
- If present, capture free-text spans like "Jun 2021 – Aug 2021" or "present".

STRICT constraints:
- IGNORE exam/test scores: SAT, ACT, GRE, GMAT, TOEFL, IELTS
- IGNORE scholarship %, ranks, percentile (Top x%), awards/honors — NOT GPA
- Do NOT invent universities, organizations, roles, dates, or GPA
- Return JSON only, no commentary
""".strip()

# ======== Helpers ========

def concat_row_text(row: pd.Series) -> str:
    return " | ".join([str(v).strip() for v in row.values if pd.notna(v) and str(v).strip()])

async def _maybe_await(x):
    if asyncio.iscoroutine(x): return await x
    return x

async def _call_agent(agent, text):
    res = await _maybe_await(agent.run(text))
    return res.output if hasattr(res, "output") else res

# ======== Badcase detection ========

def _suspicious_gpa(v, s):
    try:
        v = float(v) if v is not None and str(v) != "" else None
        s = float(s) if s is not None and str(s) != "" else None
    except:
        return True
    if v is None: return False
    if s == 4 and v > 4: return True
    if s == 100 and v <= 4.5: return True
    if v > 100 and (s is None or s <= 100): return True
    return False

_exam_pat = re.compile(r"(SAT|ACT|GRE|GMAT|TOEFL|IELTS)", re.I)

def flag_badcases(batch_df: pd.DataFrame) -> pd.DataFrame:
    if batch_df.empty: return batch_df
    df = batch_df.copy()
    # flags
    df["flag_suspicious_gpa"] = df.apply(
        lambda r: _suspicious_gpa(r.get("gpa_value"), r.get("gpa_scale"))
        if r.get("entity_type") == "education" else False, axis=1
    )
    def _exam_text(r):
        return f"{r.get('raw_gpa_text') or ''} {r.get('raw_span') or ''}"
    df["flag_exam_token"] = df.apply(lambda r: bool(_exam_pat.search(_exam_text(r))), axis=1)
    # row-level summary
    summary = (
        df.groupby("row_index", dropna=False)
          .agg(
              any_univ=("university", lambda x: x.notna().any() if "university" in df.columns else False),
              any_gpa=("gpa_value", lambda x: x.notna().any() if "gpa_value" in df.columns else False),
              suspicious=("flag_suspicious_gpa", "any"),
              exam=("flag_exam_token", "any")
          )
          .reset_index()
    )
    bad_mask = (summary["any_gpa"] & ~summary["any_univ"]) | summary["suspicious"] | summary["exam"]
    bad_rows = summary[bad_mask]
    if bad_rows.empty: return pd.DataFrame(columns=df.columns)  # no badcases in this batch
    return df.merge(bad_rows[["row_index"]], on="row_index", how="inner")

# ======== Main ========

async def _amain(args):
    if "OPENROUTER_API_KEY" not in os.environ:
        print('ERROR: setx OPENROUTER_API_KEY "sk-or-v1..."', file=sys.stderr); sys.exit(1)
    if not os.path.exists(args.csv):
        print(f"ERROR: cannot find CSV: {args.csv}", file=sys.stderr); sys.exit(1)

    # slice
    src = pd.read_csv(args.csv)
    if args.limit is not None:
        src = src.iloc[args.start: args.start + args.limit].copy()
    else:
        src = src.iloc[args.start:].copy()
    if src.empty:
        print("No rows to process.", file=sys.stderr); sys.exit(0)

    src["_text"] = src.apply(concat_row_text, axis=1)

    # build agent
    model_id = args.model or os.getenv("OPENROUTER_MODEL", "openrouter:openai/gpt-4o-mini")
    try:
        agent = Agent(model_id, instructions=INSTRUCTIONS, output_type=ExtractionResult)
    except TypeError:
        agent = Agent(model_id, system_prompt=INSTRUCTIONS, result_type=ExtractionResult)

    out_jsonl = f"{args.out}.jsonl"
    out_csv   = f"{args.out}.csv"
    out_bad   = f"{args.out}_badcases.csv"

    # truncate outputs
    open(out_jsonl, "w", encoding="utf-8").close()
    open(out_csv, "w", encoding="utf-8").close()
    open(out_bad, "w", encoding="utf-8").close()
    wrote_csv_header = False
    wrote_bad_header = False

    total = len(src)
    batches: List[Tuple[int,int]] = [(i, min(i+args.batch, total)) for i in range(0, total, args.batch)]
    print(f"Total rows: {total} | Batches: {len(batches)} | Model: {model_id} | Concurrency: {args.concurrency}")

    sem = asyncio.Semaphore(max(1, int(args.concurrency)))

    async def run_one(global_idx, text):
        async with sem:
            try:
                out = await _call_agent(agent, text)
                if args.verbose:
                    print(f"  ✔ Row {args.start + global_idx} done")
            except Exception as e:
                print(f"  ✖ Row {args.start + global_idx} failed: {e}")
                out = ExtractionResult()
            return out

    for bi, (s, e) in enumerate(batches, start=1):
        texts = src["_text"].iloc[s:e].tolist()
        tasks = [asyncio.create_task(run_one(i, t)) for i, t in enumerate(texts, start=s)]
        outputs: List[ExtractionResult] = await asyncio.gather(*tasks)

        # 1) append JSONL (per original row)
        with open(out_jsonl, "a", encoding="utf-8") as f:
            for out in outputs:
                f.write(json.dumps(out.model_dump(), ensure_ascii=False) + "\n")

        # 2) flatten this batch to CSV rows
        rows_this_batch = []
        for i, out in enumerate(outputs, start=s):
            base_idx = args.start + i
            if out.education:
                for ed in out.education:
                    rows_this_batch.append({
                        "row_index": base_idx,
                        "entity_type": "education",
                        "university": ed.university,
                        "degree": ed.degree,
                        "major": ed.major,
                        "gpa_value": ed.gpa_value,
                        "gpa_scale": ed.gpa_scale,
                        "raw_gpa_text": ed.raw_gpa_text,
                        "organization": None,
                        "role": None,
                        "employment_type": None,
                        "start_date_text": None,
                        "end_date_text": None,
                        "raw_span": None
                    })
            if out.jobs:
                for jb in out.jobs:
                    rows_this_batch.append({
                        "row_index": base_idx,
                        "entity_type": "job",
                        "university": None,
                        "degree": None,
                        "major": None,
                        "gpa_value": None,
                        "gpa_scale": None,
                        "raw_gpa_text": None,
                        "organization": jb.organization,
                        "role": jb.role,
                        "employment_type": jb.employment_type,
                        "start_date_text": jb.start_date_text,
                        "end_date_text": jb.end_date_text,
                        "raw_span": jb.raw_span
                    })
            if not (out.education or out.jobs):
                rows_this_batch.append({
                    "row_index": base_idx,
                    "entity_type": "none",
                    "university": None, "degree": None, "major": None,
                    "gpa_value": None, "gpa_scale": None, "raw_gpa_text": None,
                    "organization": None, "role": None, "employment_type": None,
                    "start_date_text": None, "end_date_text": None,
                    "raw_span": None
                })

        batch_df = pd.DataFrame(rows_this_batch)

        # 3) stream-append CSV for this batch
        batch_df.to_csv(
            out_csv, mode="a", header=not wrote_csv_header,
            index=False, encoding="utf-8-sig"
        )
        if not wrote_csv_header: wrote_csv_header = True

        # 4) make & append badcases for this batch
        bad_df = flag_badcases(batch_df)
        if not bad_df.empty:
            bad_df.to_csv(
                out_bad, mode="a", header=not wrote_bad_header,
                index=False, encoding="utf-8-sig"
            )
            if not wrote_bad_header: wrote_bad_header = True

        # 5) progress line per batch
        print(f"[Batch {bi}/{len(batches)}] rows {args.start + s}–{args.start + e - 1} finished ({len(batch_df)} rows appended)")

    print(f"Done.\nJSONL: {out_jsonl}\nCSV:   {out_csv}\nBAD:   {out_bad}")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", required=True, help="Input CSV path")
    ap.add_argument("--out", required=True, help="Output base name (without extension)")
    ap.add_argument("--start", type=int, default=0, help="Start row index (0-based)")
    ap.add_argument("--limit", type=int, default=None, help="Max rows to process; default=all")
    ap.add_argument("--batch", type=int, default=10, help="Rows per batch")
    ap.add_argument("--concurrency", type=int, default=1, help="Concurrent requests per batch (>=1)")
    ap.add_argument("--model", type=str, default=None, help='Override model id; default env OPENROUTER_MODEL or "openrouter:openai/gpt-4o-mini"')
    ap.add_argument("--verbose", action="store_true", help="Print per-row progress (very chatty)")
    args = ap.parse_args()
    try:
        asyncio.run(_amain(args))
    except RuntimeError:
        loop = asyncio.get_event_loop()
        loop.run_until_complete(_amain(args))

if __name__ == "__main__":
    main()

